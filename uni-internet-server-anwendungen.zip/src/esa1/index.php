<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<h1>Hello World</h1>'; ?> 
 <?php echo '<h2>Here are some infos abaut the site:</h2>'; ?> 
 <?php echo phpinfo(); ?> 
 </body>
</html>