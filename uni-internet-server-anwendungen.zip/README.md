Starten:

 docker build -t my-php-site:latest .  
 docker run -d -p 80:80 my-php-site:latest

 Und Seite läuft auf port 80

 TODO: 
 - Arg für esa auswahl
 - Restart script
 - Unit tests
 - ... stuff?